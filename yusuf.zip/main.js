$(document).ready(function() {
   var width = $(window).width();
   alert('lebar' + width);
})